package log

// Tag is the log tag sent to __android_log_print on android builds
var Tag = "vic-cloud"
