// +build !linux

package robot

const (
	GatewayKey  = "/tmp/anki/gateway/trust.key"
	GatewayCert = "/tmp/anki/gateway/trust.cert"
)
