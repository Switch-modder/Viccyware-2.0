package jwt

func tokenPath() string {
	return "/data/data/com.anki.victor/persistent/token"
}
