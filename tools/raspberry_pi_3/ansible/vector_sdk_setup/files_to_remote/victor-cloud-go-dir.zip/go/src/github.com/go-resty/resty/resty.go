// Copyright (c) 2015-2018 Jeevanandam M (jeeva@myjeeva.com), All rights reserved.
// resty source code and usage is governed by a MIT style
// license that can be found in the LICENSE file.

// Package resty provides simple HTTP and REST client for Go inspired by Ruby rest-client.
package resty

// Version # of resty
const Version = "1.9.0-edge"
