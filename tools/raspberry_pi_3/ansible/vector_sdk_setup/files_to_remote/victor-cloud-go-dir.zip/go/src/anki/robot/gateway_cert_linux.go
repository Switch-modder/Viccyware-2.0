// +build linux

package robot

const (
	GatewayKey  = "/data/etc/robot.pem"
	GatewayCert = "/data/vic-gateway/gateway.cert"
)
